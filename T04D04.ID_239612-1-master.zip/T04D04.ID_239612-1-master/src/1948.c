#include <stdio.h>

int absolute_value(int x) {
    if (x < 0) {
        return -x;
    }
    return x;
}

int is_divisible(int a, int b) {
   
    if (b == 0) {
        return 0;
    }
    int sum = 0;
    while (sum < a) {
        sum += b; 
    }
    if (sum == a) {
        return 1;
    }
    return 0;
}

int integer_division(int a, int b) {
    if (b == 0) {
        return 0; 
    }
    int count = 0;
    int temp = a;
    while (temp >= b) {
        temp = temp - b;
        count++;
    }
    return count;
}


int is_prime(int x) {
    if (x < 2) {
        return 0;
    }
   
    for (int i = 2; i < x; i++) {
        if (is_divisible(x, i)) {
            return 0; 
        }
    }
    return 1;
}


int largest_prime_factor(int a) {
    
    if (a == 0 || a == 1 || a == -1) {
        return -1;
    }

    int n = absolute_value(a);

    
    if (n == 1) {
        return -1;
    }

    int largestFactor = -1;

    for (int i = 2; i <= n; i++) {
        
        if (is_prime(i)) {
            
            while (is_divisible(n, i)) {
                n = integer_division(n, i);
                largestFactor = i; 
            }
           
            if (n == 1) {
                break;
            }
        }
    }
   
    if (largestFactor == -1) {
        return n;
    } else if (n > 1) {
       
        if (is_prime(n) && n > largestFactor) {
            return n;
        }
    }

    return largestFactor;
}

int main(void) {
    int a;
    if (scanf("%d", &a) != 1) {
        printf("n/a\n");
        return 0;
    }

    int result = largest_prime_factor(a);
    if (result == -1) {
        printf("n/a\n");
    } else {
        printf("%d\n", result);
    }

    return 0;
}
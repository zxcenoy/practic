#include <stdio.h>

int is_hex(char c) {
    return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
}

int hex_val(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("n/a\n");
        return 1;
    }
    
    char mode = argv[1][0];
    
    if (mode == '1') {
        char a, b;
        int count = 0;
        
        while (1) {
            a = getchar();
            if (a == '\n') {
                if (count > 0) printf("\n");
                else printf("n/a\n");
                break;
            }
            
            b = getchar();
            if (!is_hex(a) || !is_hex(b)) {
                printf("n/a\n");
                return 1;
            }
            
            int val = hex_val(a) * 16 + hex_val(b);
            if (val > 127) {
                printf("n/a\n");
                return 1;
            }
            
            if (count > 0) printf(" ");
            printf("%c", val);
            count++;
            
            char sp = getchar();
            if (sp == '\n') {
                printf("\n");
                break;
            }
            if (sp != ' ') {
                printf("n/a\n");
                return 1;
            }
        }
    }
    else if (mode == '0') {
        char ch;
        int count = 0;
        
        while (1) {
            ch = getchar();
            if (ch == '\n') {
                if (count > 0) printf("\n");
                break;
            }
            if (ch == ' ') continue;
            
            if ((unsigned char)ch > 127) {
                printf("n/a\n");
                return 1;
            }
            
            if (count > 0) printf(" ");
            printf("%02X", (unsigned char)ch);
            count++;
        }
    }
    else {
        printf("n/a\n");
        return 1;
    }
    
    return 0;
}